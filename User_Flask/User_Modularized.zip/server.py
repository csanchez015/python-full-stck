from flask_app import app

import flask_app.controllers.user_controller

if __name__=="__main__":
    app.run(debug=True)